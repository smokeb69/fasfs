import React from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { AlertCircle, TrendingUp, Shield, Zap, RefreshCw } from "lucide-react";

import { Loader2 } from "lucide-react";

const COLORS = ['#10b981', '#f97316', '#ef4444'];

export default function Dashboard() {
  const { user } = useAuth();

  const [refreshing, setRefreshing] = React.useState(false);
  
  // Fetch dashboard data
  const { data: stats, isLoading: statsLoading, refetch: refetchStats } = trpc.dashboard.getStats.useQuery();
  const { data: signatures, isLoading: signaturesLoading, refetch: refetchSigs } = trpc.dashboard.listSignatures.useQuery({ limit: 10 });
  const { data: alerts, isLoading: alertsLoading, refetch: refetchAlerts } = trpc.dashboard.listAlerts.useQuery({ limit: 10 });

  const isLoading = statsLoading || signaturesLoading || alertsLoading;
  
  const handleRefresh = async () => {
    setRefreshing(true);
    await Promise.all([refetchStats(), refetchSigs(), refetchAlerts()]);
    setRefreshing(false);
  };

  // Prepare chart data
  const riskData = stats ? [
    { name: 'Safe', value: stats.riskDistribution.green },
    { name: 'Warning', value: stats.riskDistribution.orange },
    { name: 'Critical', value: stats.riskDistribution.red },
  ] : [];

  const trendData = [
    { name: 'Mon', detections: 24, alerts: 4 },
    { name: 'Tue', detections: 13, alerts: 3 },
    { name: 'Wed', detections: 20, alerts: 2 },
    { name: 'Thu', detections: 39, alerts: 5 },
    { name: 'Fri', detections: 48, alerts: 7 },
    { name: 'Sat', detections: 38, alerts: 4 },
    { name: 'Sun', detections: 43, alerts: 6 },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-white">Dashboard</h1>
              <p className="text-slate-400 mt-1">Real-time threat monitoring and analytics</p>
            </div>
            <Button 
              onClick={handleRefresh}
              disabled={refreshing}
              variant="outline" 
              className="border-slate-600 text-white hover:bg-slate-800 flex items-center gap-2"
            >
              <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
              {refreshing ? 'Refreshing...' : 'Refresh'}
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="h-8 w-8 animate-spin text-blue-400" />
          </div>
        ) : (
          <>
            {/* Stats Grid */}
            <div className="grid md:grid-cols-4 gap-6 mb-8">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-300">Total Signatures</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="text-3xl font-bold text-white">{stats?.totalSignatures || 0}</div>
                    <Shield className="h-8 w-8 text-blue-400 opacity-50" />
                  </div>
                  <p className="text-xs text-slate-400 mt-2">AI-generated images detected</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-300">Active Alerts</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="text-3xl font-bold text-white">{stats?.totalAlerts || 0}</div>
                    <AlertCircle className="h-8 w-8 text-red-400 opacity-50" />
                  </div>
                  <p className="text-xs text-slate-400 mt-2">Pending investigation</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-300">Critical Threats</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="text-3xl font-bold text-white">{stats?.criticalAlerts || 0}</div>
                    <TrendingUp className="h-8 w-8 text-orange-400 opacity-50" />
                  </div>
                  <p className="text-xs text-slate-400 mt-2">Requires immediate action</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-300">Bloom Seeds</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="text-3xl font-bold text-white">0</div>
                    <Zap className="h-8 w-8 text-yellow-400 opacity-50" />
                  </div>
                  <p className="text-xs text-slate-400 mt-2">Active deployments</p>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid lg:grid-cols-3 gap-6 mb-8">
              {/* Risk Distribution */}
              <Card className="bg-slate-800 border-slate-700 lg:col-span-1">
                <CardHeader>
                  <CardTitle className="text-white">Risk Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={riskData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, value }) => `${name}: ${value}`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {riskData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Trend Chart */}
              <Card className="bg-slate-800 border-slate-700 lg:col-span-2">
                <CardHeader>
                  <CardTitle className="text-white">Weekly Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={trendData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
                      <XAxis stroke="#94a3b8" />
                      <YAxis stroke="#94a3b8" />
                      <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }} />
                      <Legend />
                      <Line type="monotone" dataKey="detections" stroke="#3b82f6" strokeWidth={2} />
                      <Line type="monotone" dataKey="alerts" stroke="#ef4444" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Recent Signatures and Alerts */}
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Recent Signatures */}
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Recent Signatures</CardTitle>
                  <CardDescription className="text-slate-400">Latest detected AI-generated images</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {signatures && signatures.length > 0 ? (
                      signatures.map((sig) => (
                        <div key={sig.id} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                          <div className="flex-1">
                            <p className="text-sm font-medium text-white truncate">{sig.sha256Hash.substring(0, 16)}...</p>
                            <p className="text-xs text-slate-400">{sig.modelType || 'Unknown'}</p>
                          </div>
                          <div className={`px-2 py-1 rounded text-xs font-medium ${
                            sig.riskLevel === 'red' ? 'bg-red-900/30 text-red-300' :
                            sig.riskLevel === 'orange' ? 'bg-orange-900/30 text-orange-300' :
                            'bg-green-900/30 text-green-300'
                          }`}>
                            {sig.riskLevel.toUpperCase()}
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-slate-400 text-center py-4">No signatures detected yet</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Recent Alerts */}
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Recent Alerts</CardTitle>
                  <CardDescription className="text-slate-400">Latest enforcement alerts</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {alerts && alerts.length > 0 ? (
                      alerts.map((alert) => (
                        <div key={alert.id} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                          <div className="flex-1">
                            <p className="text-sm font-medium text-white">{alert.alertType}</p>
                            <p className="text-xs text-slate-400">{new Date(alert.createdAt).toLocaleDateString()}</p>
                          </div>
                          <div className={`px-2 py-1 rounded text-xs font-medium ${
                            alert.severity === 'critical' ? 'bg-red-900/30 text-red-300' :
                            alert.severity === 'high' ? 'bg-orange-900/30 text-orange-300' :
                            alert.severity === 'medium' ? 'bg-yellow-900/30 text-yellow-300' :
                            'bg-blue-900/30 text-blue-300'
                          }`}>
                            {alert.severity.toUpperCase()}
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-slate-400 text-center py-4">No alerts yet</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
