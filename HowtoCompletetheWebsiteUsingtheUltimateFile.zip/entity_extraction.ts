import crypto from "crypto";

/**
 * Advanced Entity Extraction & NLP - Production Grade
 * Government-grade named entity recognition and relationship detection
 */

export interface Entity {
  id: string;
  text: string;
  type: "PERSON" | "ORGANIZATION" | "LOCATION" | "EMAIL" | "PHONE" | "IP_ADDRESS" | "HASH" | "URL" | "CREDENTIAL" | "FINANCIAL" | "IDENTIFIER";
  confidence: number;
  frequency: number;
  firstSeen: Date;
  lastSeen: Date;
  sources: string[];
  metadata: Record<string, any>;
  aliases: string[];
  riskScore: number;
}

export interface EntityRelationship {
  id: string;
  sourceId: string;
  targetId: string;
  type: "associated_with" | "located_in" | "works_for" | "owns" | "compromised_by" | "communicates_with" | "co-occurrence" | "other";
  strength: number;
  confidence: number;
  evidence: string[];
  frequency: number;
  metadata: Record<string, any>;
}

export interface EntitySummary {
  entity: Entity;
  relatedEntities: Entity[];
  relationships: EntityRelationship[];
  timeline: Array<{ date: Date; event: string }>;
  riskScore: number;
  summary: string;
  threatLevel: "critical" | "high" | "medium" | "low";
}

/**
 * Named Entity Recognizer - Advanced NLP
 */
export class NamedEntityRecognizer {
  private entities: Map<string, Entity> = new Map();
  private relationships: EntityRelationship[] = [];
  private patterns: Map<string, RegExp>;

  constructor() {
    this.patterns = new Map();
    this.initializePatterns();
  }

  /**
   * Initialize advanced entity recognition patterns
   */
  private initializePatterns(): void {
    this.patterns.set("EMAIL", /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g);
    this.patterns.set("PHONE", /\b(?:\+?1[-.\s]?)?\(?([0-9]{3})\)?[-.\s]?([0-9]{3})[-.\s]?([0-9]{4})\b/g);
    this.patterns.set("IP_ADDRESS", /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/g);
    this.patterns.set("URL", /https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&/=]*)/g);
    this.patterns.set("HASH", /\b(?:[a-fA-F0-9]{32}|[a-fA-F0-9]{40}|[a-fA-F0-9]{64})\b/g);
    this.patterns.set("FINANCIAL", /\b(?:\d{4}[-\s]?){3}\d{4}\b/g);
  }

  /**
   * Extract entities from text
   */
  extractEntities(text: string, source: string): Entity[] {
    const extractedEntities: Entity[] = [];

    // Pattern-based extraction
    for (const [entityType, pattern] of Array.from(this.patterns)) {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        const entity = this.createOrUpdateEntity(match[0], entityType, source, this.getConfidence(entityType));
        extractedEntities.push(entity);
      }
    }

    // Person extraction (advanced)
    const personPattern = /\b[A-Z][a-z]+ [A-Z][a-z]+\b/g;
    const persons = text.match(personPattern) || [];
    for (const person of persons) {
      const entity = this.createOrUpdateEntity(person, "PERSON", source, 0.85);
      extractedEntities.push(entity);
    }

    // Organization extraction
    const orgPattern = /\b[A-Z][a-z]+ (?:Inc|Corp|LLC|Ltd|Co|Group|Labs|AI|Systems|Agency|Department)\b/g;
    const orgs = text.match(orgPattern) || [];
    for (const org of orgs) {
      const entity = this.createOrUpdateEntity(org, "ORGANIZATION", source, 0.88);
      extractedEntities.push(entity);
    }

    // Location extraction
    const locations = ["New York", "Los Angeles", "San Francisco", "London", "Tokyo", "Berlin", "Paris", "Sydney", "Toronto", "Dubai", "Moscow", "Beijing"];
    for (const location of locations) {
      const regex = new RegExp(`\\b${location}\\b`, "g");
      let match;
      while ((match = regex.exec(text)) !== null) {
        const entity = this.createOrUpdateEntity(location, "LOCATION", source, 0.90);
        extractedEntities.push(entity);
      }
    }

    return extractedEntities;
  }

  /**
   * Get confidence score for entity type
   */
  private getConfidence(entityType: string): number {
    const confidenceMap: Record<string, number> = {
      EMAIL: 0.99,
      PHONE: 0.95,
      IP_ADDRESS: 0.98,
      URL: 0.97,
      HASH: 0.96,
      FINANCIAL: 0.92,
      PERSON: 0.85,
      ORGANIZATION: 0.88,
      LOCATION: 0.90,
    };
    return confidenceMap[entityType] || 0.80;
  }

  /**
   * Create or update entity
   */
  private createOrUpdateEntity(text: string, type: string, source: string, confidence: number): Entity {
    const key = `${type}:${text.toLowerCase()}`;

    if (this.entities.has(key)) {
      const entity = this.entities.get(key)!;
      entity.frequency++;
      entity.lastSeen = new Date();
      entity.sources.push(source);
      return entity;
    }

    const entity: Entity = {
      id: `entity_${crypto.randomBytes(8).toString("hex")}`,
      text,
      type: type as any,
      confidence,
      frequency: 1,
      firstSeen: new Date(),
      lastSeen: new Date(),
      sources: [source],
      metadata: {},
      aliases: this.extractAliases(text, type),
      riskScore: this.calculateRiskScore(type, text),
    };

    this.entities.set(key, entity);
    return entity;
  }

  /**
   * Extract aliases for entity
   */
  private extractAliases(text: string, type: string): string[] {
    const aliases: string[] = [];

    if (type === "EMAIL") {
      const username = text.split("@")[0];
      aliases.push(username);
    }

    if (type === "URL") {
      const domain = text.split("://")[1]?.split("/")[0];
      if (domain) aliases.push(domain);
    }

    if (type === "PERSON") {
      const parts = text.split(" ");
      aliases.push(...parts);
    }

    return aliases;
  }

  /**
   * Calculate risk score
   */
  private calculateRiskScore(type: string, value: string): number {
    const riskMap: Record<string, number> = {
      EMAIL: 0.4,
      PHONE: 0.3,
      IP_ADDRESS: 0.6,
      URL: 0.7,
      HASH: 0.8,
      FINANCIAL: 0.9,
      PERSON: 0.3,
      ORGANIZATION: 0.2,
      LOCATION: 0.1,
    };
    return riskMap[type] || 0.5;
  }

  /**
   * Extract relationships between entities
   */
  extractRelationships(text: string): EntityRelationship[] {
    const relationships: EntityRelationship[] = [];
    const entities = Array.from(this.entities.values());

    for (let i = 0; i < entities.length; i++) {
      for (let j = i + 1; j < entities.length; j++) {
        const entity1 = entities[i];
        const entity2 = entities[j];

        if (text.includes(entity1.text) && text.includes(entity2.text)) {
          const idx1 = text.indexOf(entity1.text);
          const idx2 = text.indexOf(entity2.text);
          const distance = Math.abs(idx1 - idx2);

          if (distance < 500) {
            const relationship: EntityRelationship = {
              id: `rel_${crypto.randomBytes(8).toString("hex")}`,
              sourceId: entity1.id,
              targetId: entity2.id,
              type: "co-occurrence",
              strength: Math.max(0, 1 - distance / 500),
              confidence: Math.min(entity1.confidence, entity2.confidence),
              evidence: [text.substring(Math.max(0, Math.min(idx1, idx2) - 50), Math.max(idx1, idx2) + 50)],
              frequency: 1,
              metadata: { distance },
            };

            relationships.push(relationship);
            this.relationships.push(relationship);
          }
        }
      }
    }

    return relationships;
  }

  /**
   * Get all entities
   */
  getEntities(): Entity[] {
    return Array.from(this.entities.values());
  }

  /**
   * Get entity by ID
   */
  getEntity(id: string): Entity | undefined {
    return this.entities.get(id);
  }

  /**
   * Get entities by type
   */
  getEntitiesByType(type: string): Entity[] {
    return Array.from(this.entities.values()).filter((e) => e.type === type);
  }

  /**
   * Get relationships for an entity
   */
  getRelationships(entityId: string): EntityRelationship[] {
    return this.relationships.filter((r) => r.sourceId === entityId || r.targetId === entityId);
  }

  /**
   * Get statistics
   */
  getStatistics() {
    const entities = Array.from(this.entities.values());
    const entitiesByType: Record<string, number> = {};

    for (const entity of entities) {
      entitiesByType[entity.type] = (entitiesByType[entity.type] || 0) + 1;
    }

    const totalFrequency = entities.reduce((sum, e) => sum + e.frequency, 0);

    return {
      totalEntities: entities.length,
      entitiesByType,
      totalRelationships: this.relationships.length,
      averageFrequency: entities.length > 0 ? totalFrequency / entities.length : 0,
    };
  }
}

/**
 * Entity Summarizer - Advanced Analysis
 */
export class EntitySummarizer {
  private recognizer: NamedEntityRecognizer;

  constructor(recognizer: NamedEntityRecognizer) {
    this.recognizer = recognizer;
  }

  /**
   * Generate comprehensive summary
   */
  generateSummary(entityId: string): EntitySummary | null {
    const entity = this.recognizer.getEntity(entityId);
    if (!entity) return null;

    const relationships = this.recognizer.getRelationships(entityId);
    const relatedEntityIds = new Set<string>();

    for (const rel of relationships) {
      if (rel.sourceId === entityId) {
        relatedEntityIds.add(rel.targetId);
      } else {
        relatedEntityIds.add(rel.sourceId);
      }
    }

    const relatedEntities = Array.from(relatedEntityIds)
      .map((id) => this.recognizer.getEntity(id))
      .filter((e) => e !== undefined) as Entity[];

    const riskScore = this.calculateRiskScore(entity, relationships);
    const threatLevel = this.calculateThreatLevel(riskScore);
    const summary = this.generateTextSummary(entity, relatedEntities, relationships);

    return {
      entity,
      relatedEntities,
      relationships,
      timeline: this.generateTimeline(entity),
      riskScore,
      summary,
      threatLevel,
    };
  }

  /**
   * Calculate comprehensive risk score
   */
  private calculateRiskScore(entity: Entity, relationships: EntityRelationship[]): number {
    let score = 0;

    score += Math.min(entity.frequency / 10, 0.3);
    score += Math.min(relationships.length / 20, 0.3);
    score += (1 - entity.confidence) * 0.2;
    score += entity.riskScore * 0.2;

    return Math.min(score, 1.0);
  }

  /**
   * Calculate threat level
   */
  private calculateThreatLevel(riskScore: number): "critical" | "high" | "medium" | "low" {
    if (riskScore > 0.75) return "critical";
    if (riskScore > 0.5) return "high";
    if (riskScore > 0.25) return "medium";
    return "low";
  }

  /**
   * Generate text summary
   */
  private generateTextSummary(entity: Entity, relatedEntities: Entity[], relationships: EntityRelationship[]): string {
    let summary = `Entity: ${entity.text} (${entity.type})\n`;
    summary += `Frequency: ${entity.frequency} occurrences\n`;
    summary += `Confidence: ${(entity.confidence * 100).toFixed(1)}%\n`;
    summary += `Risk Score: ${(entity.riskScore * 100).toFixed(1)}%\n`;
    summary += `First Seen: ${entity.firstSeen.toISOString()}\n`;
    summary += `Last Seen: ${entity.lastSeen.toISOString()}\n`;

    if (relatedEntities.length > 0) {
      summary += `\nRelated Entities: ${relatedEntities.map((e) => e.text).join(", ")}\n`;
    }

    if (relationships.length > 0) {
      summary += `\nRelationships: ${relationships.length} connections found\n`;
    }

    return summary;
  }

  /**
   * Generate timeline
   */
  private generateTimeline(entity: Entity): Array<{ date: Date; event: string }> {
    return [
      {
        date: entity.firstSeen,
        event: `Entity first detected: ${entity.text}`,
      },
      {
        date: entity.lastSeen,
        event: `Entity last seen: ${entity.text}`,
      },
    ];
  }
}

/**
 * Entity Linker - Relationship Mapping
 */
export class EntityLinker {
  /**
   * Link entities based on similarity
   */
  linkEntities(entities: Entity[]): Map<string, string[]> {
    const linkedEntities = new Map<string, string[]>();

    for (let i = 0; i < entities.length; i++) {
      for (let j = i + 1; j < entities.length; j++) {
        const similarity = this.calculateSimilarity(entities[i], entities[j]);

        if (similarity > 0.8) {
          const key = entities[i].id;
          if (!linkedEntities.has(key)) {
            linkedEntities.set(key, []);
          }
          linkedEntities.get(key)!.push(entities[j].id);
        }
      }
    }

    return linkedEntities;
  }

  /**
   * Calculate similarity between entities
   */
  private calculateSimilarity(entity1: Entity, entity2: Entity): number {
    if (entity1.type !== entity2.type) return 0;

    const text1 = entity1.text.toLowerCase();
    const text2 = entity2.text.toLowerCase();

    if (text1 === text2) return 1.0;

    const distance = this.levenshteinDistance(text1, text2);
    const maxLength = Math.max(text1.length, text2.length);

    return 1 - distance / maxLength;
  }

  /**
   * Calculate Levenshtein distance
   */
  private levenshteinDistance(str1: string, str2: string): number {
    const matrix: number[][] = [];

    for (let i = 0; i <= str2.length; i++) {
      matrix[i] = [i];
    }

    for (let j = 0; j <= str1.length; j++) {
      matrix[0][j] = j;
    }

    for (let i = 1; i <= str2.length; i++) {
      for (let j = 1; j <= str1.length; j++) {
        if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          );
        }
      }
    }

    return matrix[str2.length][str1.length];
  }
}
