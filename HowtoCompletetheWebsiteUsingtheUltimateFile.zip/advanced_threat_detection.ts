import crypto from "crypto";

/**
 * Advanced Threat Detection Engine - Production Grade
 * Government-grade threat detection for law enforcement
 * Implements multi-layered detection: pattern, behavioral, statistical, and correlation-based
 */

export interface ThreatSignature {
  id: string;
  name: string;
  pattern: RegExp | string;
  severity: "critical" | "high" | "medium" | "low";
  category: string;
  indicators: string[];
  confidence: number;
  ttl: number;
  mitre_att_ck: string[];
}

export interface DetectedThreat {
  threatId: string;
  type: string;
  severity: "critical" | "high" | "medium" | "low";
  confidence: number;
  timestamp: Date;
  source: string;
  indicators: string[];
  metadata: Record<string, any>;
  mitigationSteps: string[];
  riskScore: number;
  mitre_att_ck: string[];
}

export interface AnomalyScore {
  baseline: number;
  current: number;
  deviation: number;
  isAnomaly: boolean;
  confidence: number;
  zScore: number;
}

// Advanced threat signatures database
const THREAT_SIGNATURES: ThreatSignature[] = [
  {
    id: "sig_001",
    name: "SQL Injection Attack",
    pattern: /(\bUNION\b|\bSELECT\b|\bINSERT\b|\bUPDATE\b|\bDELETE\b|\bDROP\b).*(-{2}|\/\*|\*\/|;)/i,
    severity: "critical",
    category: "injection",
    indicators: ["union-based", "time-based", "error-based", "boolean-based"],
    confidence: 0.95,
    ttl: 3600,
    mitre_att_ck: ["T1190"],
  },
  {
    id: "sig_002",
    name: "Cross-Site Scripting (XSS)",
    pattern: /<script[^>]*>[\s\S]*?<\/script>|javascript:|on\w+\s*=/i,
    severity: "high",
    category: "injection",
    indicators: ["stored-xss", "reflected-xss", "dom-xss"],
    confidence: 0.92,
    ttl: 3600,
    mitre_att_ck: ["T1598"],
  },
  {
    id: "sig_003",
    name: "Command Injection",
    pattern: /[;&|`$(){}[\]<>\\]/,
    severity: "critical",
    category: "injection",
    indicators: ["shell-metacharacters", "command-chaining"],
    confidence: 0.88,
    ttl: 3600,
    mitre_att_ck: ["T1059"],
  },
  {
    id: "sig_004",
    name: "Path Traversal",
    pattern: /\.\.[\/\\]|\.\.[\/\\]\.\.[\/\\]/,
    severity: "high",
    category: "access-control",
    indicators: ["directory-traversal", "file-inclusion"],
    confidence: 0.90,
    ttl: 3600,
    mitre_att_ck: ["T1083"],
  },
  {
    id: "sig_005",
    name: "Brute Force Attack",
    pattern: "multiple-failed-attempts",
    severity: "high",
    category: "authentication",
    indicators: ["failed-login", "password-spray", "credential-stuffing"],
    confidence: 0.85,
    ttl: 300,
    mitre_att_ck: ["T1110"],
  },
  {
    id: "sig_006",
    name: "DDoS Attack Pattern",
    pattern: "high-request-volume",
    severity: "critical",
    category: "availability",
    indicators: ["volumetric", "protocol-based", "application-layer"],
    confidence: 0.93,
    ttl: 60,
    mitre_att_ck: ["T1498"],
  },
  {
    id: "sig_007",
    name: "Malware Signature",
    pattern: /powershell|cmd\.exe|wmic|psexec|mimikatz|rundll32|regsvcs/i,
    severity: "critical",
    category: "malware",
    indicators: ["windows-malware", "credential-theft", "lateral-movement"],
    confidence: 0.96,
    ttl: 7200,
    mitre_att_ck: ["T1566", "T1204"],
  },
  {
    id: "sig_008",
    name: "Privilege Escalation",
    pattern: /sudo|runas|setuid|chmod.*777|UAC.*bypass|elevation/i,
    severity: "critical",
    category: "privilege-escalation",
    indicators: ["kernel-exploit", "service-misconfiguration", "token-impersonation"],
    confidence: 0.91,
    ttl: 3600,
    mitre_att_ck: ["T1134", "T1548"],
  },
  {
    id: "sig_009",
    name: "Data Exfiltration",
    pattern: /exfiltrate|steal|extract|download.*sensitive|upload.*data/i,
    severity: "critical",
    category: "data-loss",
    indicators: ["large-data-transfer", "unusual-destination", "encryption"],
    confidence: 0.89,
    ttl: 3600,
    mitre_att_ck: ["T1020", "T1030"],
  },
  {
    id: "sig_010",
    name: "Lateral Movement",
    pattern: /psexec|wmic|smbexec|ssh.*key|rdp.*session/i,
    severity: "critical",
    category: "lateral-movement",
    indicators: ["network-scanning", "credential-reuse", "share-enumeration"],
    confidence: 0.87,
    ttl: 3600,
    mitre_att_ck: ["T1570", "T1570"],
  },
];

// Behavioral baseline for anomaly detection
const BEHAVIORAL_BASELINE = {
  avgRequestSize: 2048,
  avgResponseTime: 200,
  normalErrorRate: 0.02,
  normalFailureRate: 0.01,
  peakHourRequests: 1000,
  normalDataTransfer: 10485760, // 10MB
  avgConnectionDuration: 30000, // 30 seconds
};

/**
 * Advanced Threat Detection Engine
 * Uses pattern matching, statistical analysis, behavioral heuristics, and correlation
 */
export class ThreatDetectionEngine {
  private signatures: Map<string, ThreatSignature>;
  private detectionHistory: DetectedThreat[];
  private anomalyScores: Map<string, AnomalyScore>;
  private baselineStats: Map<string, any>;

  constructor() {
    this.signatures = new Map();
    this.detectionHistory = [];
    this.anomalyScores = new Map();
    this.baselineStats = new Map();

    // Initialize signatures
    THREAT_SIGNATURES.forEach((sig) => {
      this.signatures.set(sig.id, sig);
    });
  }

  /**
   * Detect threats in event stream using multi-layered approach
   */
  async detectThreats(
    events: Array<{
      type: string;
      payload: any;
      timestamp: number;
      source: string;
      destination?: string;
      metadata?: Record<string, any>;
    }>
  ): Promise<DetectedThreat[]> {
    const detectedThreats: DetectedThreat[] = [];

    // Layer 1: Pattern-based detection
    const patternMatches = this.detectPatternMatches(events);
    detectedThreats.push(...patternMatches);

    // Layer 2: Behavioral anomaly detection
    const anomalies = this.detectBehavioralAnomalies(events);
    detectedThreats.push(...anomalies);

    // Layer 3: Statistical outlier detection
    const outliers = this.detectStatisticalOutliers(events);
    detectedThreats.push(...outliers);

    // Layer 4: Correlation analysis
    const correlations = this.detectCorrelations(events);
    detectedThreats.push(...correlations);

    // Layer 5: Attack chain detection
    const chains = this.detectAttackChains(events);
    detectedThreats.push(...chains);

    // Deduplicate and score threats
    const uniqueThreats = this.deduplicateThreats(detectedThreats);
    const scoredThreats = uniqueThreats.map((threat) =>
      this.scoreAndEnrichThreat(threat)
    );

    // Store in history
    this.detectionHistory.push(...scoredThreats);

    // Cleanup old history
    this.clearOldHistory();

    return scoredThreats.sort((a, b) => b.riskScore - a.riskScore);
  }

  /**
   * Layer 1: Pattern-based threat detection
   */
  private detectPatternMatches(events: any[]): DetectedThreat[] {
    const threats: DetectedThreat[] = [];

    for (const event of events) {
      const eventString = JSON.stringify(event);

      for (const [sigId, signature] of Array.from(this.signatures)) {
        let isMatch = false;

        if (typeof signature.pattern === "string") {
          isMatch = eventString.includes(signature.pattern);
        } else {
          isMatch = signature.pattern.test(eventString);
        }

        if (isMatch) {
          threats.push({
            threatId: `threat_${crypto.randomBytes(8).toString("hex")}`,
            type: signature.category,
            severity: signature.severity,
            confidence: signature.confidence,
            timestamp: new Date(),
            source: event.source || "unknown",
            indicators: signature.indicators,
            metadata: {
              signatureId: sigId,
              signatureName: signature.name,
              eventType: event.type,
              detectionMethod: "pattern-matching",
            },
            mitigationSteps: this.getMitigationSteps(signature.category),
            riskScore: this.calculateRiskScore(signature.severity, signature.confidence),
            mitre_att_ck: signature.mitre_att_ck,
          });
        }
      }
    }

    return threats;
  }

  /**
   * Layer 2: Behavioral anomaly detection using statistical methods
   */
  private detectBehavioralAnomalies(events: any[]): DetectedThreat[] {
    const threats: DetectedThreat[] = [];

    // Analyze request size anomalies
    const requestSizes = events.map((e) => JSON.stringify(e).length);
    const avgSize = requestSizes.reduce((a, b) => a + b, 0) / requestSizes.length;
    const stdDev = Math.sqrt(
      requestSizes.reduce((sum, size) => sum + Math.pow(size - avgSize, 2), 0) /
        requestSizes.length
    );

    for (const event of events) {
      const size = JSON.stringify(event).length;
      const zScore = Math.abs((size - avgSize) / stdDev);

      if (zScore > 3) {
        // 3 standard deviations
        threats.push({
          threatId: `threat_${crypto.randomBytes(8).toString("hex")}`,
          type: "behavioral-anomaly",
          severity: zScore > 5 ? "critical" : "high",
          confidence: Math.min(0.95, 0.5 + zScore * 0.05),
          timestamp: new Date(),
          source: event.source || "unknown",
          indicators: ["unusual-request-size", "statistical-outlier"],
          metadata: {
            zScore,
            expectedSize: avgSize,
            actualSize: size,
            stdDeviation: stdDev,
            detectionMethod: "behavioral-anomaly",
          },
          mitigationSteps: [
            "Review request payload",
            "Check for data exfiltration",
            "Monitor for repeated patterns",
            "Implement size-based rate limiting",
          ],
          riskScore: 0.75,
          mitre_att_ck: ["T1020"],
        });
      }
    }

    return threats;
  }

  /**
   * Layer 3: Statistical outlier detection
   */
  private detectStatisticalOutliers(events: any[]): DetectedThreat[] {
    const threats: DetectedThreat[] = [];
    const eventTypeMap = new Map<string, number>();

    // Count event types
    for (const event of events) {
      eventTypeMap.set(event.type, (eventTypeMap.get(event.type) || 0) + 1);
    }

    // Calculate statistics
    const counts = Array.from(eventTypeMap.values());
    const mean = counts.reduce((a, b) => a + b, 0) / counts.length;
    const variance =
      counts.reduce((sum, count) => sum + Math.pow(count - mean, 2), 0) /
      counts.length;
    const stdDev = Math.sqrt(variance);

    // Detect outliers
    for (const [eventType, count] of Array.from(eventTypeMap)) {
      const zScore = Math.abs((count - mean) / stdDev);

      if (zScore > 3) {
        threats.push({
          threatId: `threat_${crypto.randomBytes(8).toString("hex")}`,
          type: "statistical-anomaly",
          severity: zScore > 5 ? "high" : "medium",
          confidence: Math.min(0.9, 0.5 + zScore * 0.05),
          timestamp: new Date(),
          source: "system",
          indicators: ["elevated-event-frequency", "statistical-outlier"],
          metadata: {
            eventType,
            expectedCount: mean,
            actualCount: count,
            zScore,
            stdDeviation: stdDev,
            detectionMethod: "statistical-outlier",
          },
          mitigationSteps: [
            "Investigate event logs",
            "Check system health",
            "Review recent changes",
            "Analyze event patterns",
          ],
          riskScore: 0.65,
          mitre_att_ck: [],
        });
      }
    }

    return threats;
  }

  /**
   * Layer 4: Correlation-based threat detection
   */
  private detectCorrelations(events: any[]): DetectedThreat[] {
    const threats: DetectedThreat[] = [];

    // Check for correlated suspicious activities
    const recentThreats = this.detectionHistory.slice(-20);
    const threatTypes = recentThreats.map((t) => t.type);

    // Detect attack chains
    const hasAuthFailure = threatTypes.includes("authentication");
    const hasPrivEsc = threatTypes.includes("privilege-escalation");
    const hasLateralMove = threatTypes.includes("lateral-movement");

    if (hasAuthFailure && hasPrivEsc) {
      threats.push({
        threatId: `threat_${crypto.randomBytes(8).toString("hex")}`,
        type: "attack-chain",
        severity: "critical",
        confidence: 0.94,
        timestamp: new Date(),
        source: events[0]?.source || "unknown",
        indicators: ["multi-stage-attack", "lateral-movement", "privilege-escalation"],
        metadata: {
          correlatedThreats: recentThreats.length,
          threatChain: "authentication -> privilege-escalation",
          detectionMethod: "correlation-analysis",
        },
        mitigationSteps: [
          "Isolate affected systems immediately",
          "Revoke all credentials",
          "Conduct forensic analysis",
          "Implement network segmentation",
          "Enable enhanced logging",
        ],
        riskScore: 0.95,
        mitre_att_ck: ["T1134", "T1548", "T1570"],
      });
    }

    if (hasPrivEsc && hasLateralMove) {
      threats.push({
        threatId: `threat_${crypto.randomBytes(8).toString("hex")}`,
        type: "advanced-persistent-threat",
        severity: "critical",
        confidence: 0.92,
        timestamp: new Date(),
        source: events[0]?.source || "unknown",
        indicators: ["apt-indicators", "multi-stage-attack", "persistence"],
        metadata: {
          correlatedThreats: recentThreats.length,
          threatChain: "privilege-escalation -> lateral-movement",
          detectionMethod: "correlation-analysis",
        },
        mitigationSteps: [
          "Activate incident response team",
          "Isolate all affected systems",
          "Conduct comprehensive forensics",
          "Review all access logs",
          "Implement network isolation",
        ],
        riskScore: 0.98,
        mitre_att_ck: ["T1134", "T1570", "T1547"],
      });
    }

    return threats;
  }

  /**
   * Layer 5: Attack chain detection
   */
  private detectAttackChains(events: any[]): DetectedThreat[] {
    const threats: DetectedThreat[] = [];
    const eventSequence: string[] = [];

    // Build event sequence
    for (const event of events.sort((a, b) => a.timestamp - b.timestamp)) {
      eventSequence.push(event.type);
    }

    // Define known attack chains
    const attackChains = [
      {
        name: "Reconnaissance -> Exploitation -> Persistence",
        pattern: ["scan", "exploit", "persistence"],
        severity: "critical" as const,
      },
      {
        name: "Initial Access -> Privilege Escalation -> Lateral Movement",
        pattern: ["initial_access", "privilege_escalation", "lateral_movement"],
        severity: "critical" as const,
      },
      {
        name: "Credential Access -> Lateral Movement -> Data Exfiltration",
        pattern: ["credential_access", "lateral_movement", "data_exfiltration"],
        severity: "critical" as const,
      },
    ];

    // Check for attack chains
    for (const chain of attackChains) {
      if (this.matchesSequence(eventSequence, chain.pattern)) {
        threats.push({
          threatId: `threat_${crypto.randomBytes(8).toString("hex")}`,
          type: "attack-chain",
          severity: chain.severity,
          confidence: 0.93,
          timestamp: new Date(),
          source: events[0]?.source || "unknown",
          indicators: chain.pattern,
          metadata: {
            chainName: chain.name,
            eventSequence,
            detectionMethod: "attack-chain-detection",
          },
          mitigationSteps: [
            "Activate incident response",
            "Isolate affected systems",
            "Preserve evidence",
            "Conduct forensic analysis",
          ],
          riskScore: 0.96,
          mitre_att_ck: ["T1595", "T1190", "T1547"],
        });
      }
    }

    return threats;
  }

  /**
   * Check if event sequence matches attack pattern
   */
  private matchesSequence(sequence: string[], pattern: string[]): boolean {
    let patternIndex = 0;

    for (const event of sequence) {
      if (patternIndex < pattern.length && event.includes(pattern[patternIndex])) {
        patternIndex++;
      }
    }

    return patternIndex === pattern.length;
  }

  /**
   * Deduplicate threats based on similarity
   */
  private deduplicateThreats(threats: DetectedThreat[]): DetectedThreat[] {
    const seen = new Map<string, DetectedThreat>();

    for (const threat of threats) {
      const key = `${threat.type}_${threat.source}`;
      const existing = seen.get(key);

      if (existing) {
        // Keep the one with higher confidence
        if (threat.confidence > existing.confidence) {
          seen.set(key, threat);
        }
      } else {
        seen.set(key, threat);
      }
    }

    return Array.from(seen.values());
  }

  /**
   * Score and enrich threat with additional context
   */
  private scoreAndEnrichThreat(threat: DetectedThreat): DetectedThreat {
    const baseScore = this.calculateRiskScore(threat.severity, threat.confidence);

    // Increase score based on threat history
    const similarThreats = this.detectionHistory.filter(
      (t) => t.type === threat.type && t.source === threat.source
    );
    const frequencyMultiplier = 1 + Math.min(similarThreats.length * 0.1, 0.5);

    // Increase score if it's part of an attack chain
    const isPartOfChain = this.detectionHistory.some(
      (t) => t.type === "attack-chain" && t.indicators.includes(threat.type)
    );
    const chainMultiplier = isPartOfChain ? 1.3 : 1.0;

    return {
      ...threat,
      riskScore: Math.min(1.0, baseScore * frequencyMultiplier * chainMultiplier),
    };
  }

  /**
   * Calculate risk score based on severity and confidence
   */
  private calculateRiskScore(
    severity: "critical" | "high" | "medium" | "low",
    confidence: number
  ): number {
    const severityScores = {
      critical: 0.95,
      high: 0.75,
      medium: 0.5,
      low: 0.25,
    };

    return severityScores[severity] * confidence;
  }

  /**
   * Get mitigation steps based on threat category
   */
  private getMitigationSteps(category: string): string[] {
    const mitigationMap: Record<string, string[]> = {
      injection: [
        "Implement input validation and sanitization",
        "Use parameterized queries and prepared statements",
        "Apply Web Application Firewall (WAF) rules",
        "Review and patch vulnerable code",
        "Implement output encoding",
      ],
      "access-control": [
        "Review and audit access control lists",
        "Implement least privilege principle",
        "Audit file and directory permissions",
        "Enable comprehensive access logging",
        "Implement multi-factor authentication",
      ],
      authentication: [
        "Enforce strong password policies",
        "Enable multi-factor authentication",
        "Implement account lockout policies",
        "Monitor and alert on failed login attempts",
        "Review and revoke compromised credentials",
      ],
      availability: [
        "Activate DDoS mitigation services",
        "Scale infrastructure capacity",
        "Implement rate limiting and throttling",
        "Enable traffic filtering and WAF",
        "Route through CDN with DDoS protection",
      ],
      malware: [
        "Isolate affected systems immediately",
        "Run comprehensive antivirus and malware scans",
        "Conduct forensic analysis",
        "Restore from clean backups",
        "Implement endpoint protection",
      ],
      "privilege-escalation": [
        "Patch all system vulnerabilities",
        "Review sudo/runas configurations",
        "Implement privilege boundary enforcement",
        "Enable privilege escalation logging",
        "Implement application whitelisting",
      ],
      "lateral-movement": [
        "Segment network into security zones",
        "Implement micro-segmentation",
        "Monitor inter-system communications",
        "Disable unnecessary network services",
        "Implement zero-trust architecture",
      ],
      "data-loss": [
        "Block outbound connections to suspicious destinations",
        "Isolate affected systems",
        "Conduct forensic analysis",
        "Notify data protection officer",
        "Implement data loss prevention (DLP)",
      ],
    };

    return mitigationMap[category] || [
      "Investigate threat immediately",
      "Isolate if necessary",
      "Document all findings",
      "Escalate to incident response team",
    ];
  }

  /**
   * Get threat detection statistics
   */
  getStatistics() {
    const totalThreats = this.detectionHistory.length;
    const criticalThreats = this.detectionHistory.filter(
      (t) => t.severity === "critical"
    ).length;
    const highThreats = this.detectionHistory.filter(
      (t) => t.severity === "high"
    ).length;
    const mediumThreats = this.detectionHistory.filter(
      (t) => t.severity === "medium"
    ).length;
    const avgConfidence =
      this.detectionHistory.reduce((sum, t) => sum + t.confidence, 0) /
      Math.max(totalThreats, 1);
    const avgRiskScore =
      this.detectionHistory.reduce((sum, t) => sum + t.riskScore, 0) /
      Math.max(totalThreats, 1);

    return {
      totalThreats,
      criticalThreats,
      highThreats,
      mediumThreats,
      avgConfidence,
      avgRiskScore,
      detectionRate: (totalThreats / Math.max(totalThreats + 1, 1)) * 100,
      threatTypes: Array.from(
        new Set(this.detectionHistory.map((t) => t.type))
      ),
    };
  }

  /**
   * Clear old threat history
   */
  private clearOldHistory(maxAge: number = 604800000) {
    // 7 days
    const cutoffTime = Date.now() - maxAge;
    this.detectionHistory = this.detectionHistory.filter(
      (t) => t.timestamp.getTime() > cutoffTime
    );
  }
}

// Export singleton instance
export const threatDetectionEngine = new ThreatDetectionEngine();

/**
 * Detect threats in event stream
 */
export async function detectThreats(
  eventStream: Array<{
    type: string;
    payload: any;
    timestamp: number;
    source: string;
    destination?: string;
    metadata?: Record<string, any>;
  }>
): Promise<DetectedThreat[]> {
  return threatDetectionEngine.detectThreats(eventStream);
}

/**
 * Get threat detection statistics
 */
export function getThreatStatistics() {
  return threatDetectionEngine.getStatistics();
}
