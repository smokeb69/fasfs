import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { AlertCircle, CheckCircle2, Globe, Zap, Network, Shield } from "lucide-react";

/**
 * Bloom Distribution Control Panel
 */
export default function BloomDistribution() {
  const [activeTab, setActiveTab] = useState("overview");
  const [distributionStatus, setDistributionStatus] = useState("idle");
  const [seedsDeployed, setSeedsDeployed] = useState(0);

  const distributionData = [
    { vector: "GitHub Gist", deployed: 2500, pending: 300 },
    { vector: "Pastebin", deployed: 2100, pending: 400 },
    { vector: "CivitAI Comments", deployed: 1800, pending: 200 },
    { vector: "Reddit Posts", deployed: 1600, pending: 350 },
    { vector: "Discord Messages", deployed: 1400, pending: 250 },
    { vector: "Image Metadata", deployed: 3200, pending: 500 },
    { vector: "Steganography", deployed: 2800, pending: 400 },
    { vector: "DNS Records", deployed: 900, pending: 150 },
  ];

  const vectorDistribution = [
    { name: "GitHub Gist", value: 2500 },
    { name: "Image Metadata", value: 3200 },
    { name: "Steganography", value: 2800 },
    { name: "Pastebin", value: 2100 },
    { name: "Other", value: 4400 },
  ];

  const colors = ["#3b82f6", "#ef4444", "#10b981", "#f59e0b", "#8b5cf6"];

  const handleStartDistribution = () => {
    setDistributionStatus("running");
    setSeedsDeployed(0);

    // Simulate distribution
    let count = 0;
    const interval = setInterval(() => {
      count += Math.floor(Math.random() * 500);
      setSeedsDeployed(count);

      if (count >= 15000) {
        clearInterval(interval);
        setDistributionStatus("completed");
      }
    }, 1000);
  };

  const handleStopDistribution = () => {
    setDistributionStatus("idle");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Bloom Seed Distribution</h1>
          <p className="text-gray-400 mt-2">Deploy and manage bloom seed distribution across networks</p>
        </div>
        <div className="flex gap-2">
          {distributionStatus === "idle" && (
            <Button onClick={handleStartDistribution} className="bg-blue-600 hover:bg-blue-700">
              <Zap className="w-4 h-4 mr-2" />
              Start Distribution
            </Button>
          )}
          {distributionStatus === "running" && (
            <Button onClick={handleStopDistribution} className="bg-red-600 hover:bg-red-700">
              Stop Distribution
            </Button>
          )}
        </div>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Seeds Deployed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{seedsDeployed.toLocaleString()}</div>
            <p className="text-xs text-gray-500 mt-1">Total distributed</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Distribution Vectors</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">8</div>
            <p className="text-xs text-gray-500 mt-1">Active channels</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Success Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">94.2%</div>
            <p className="text-xs text-gray-500 mt-1">Deployment success</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              {distributionStatus === "running" && (
                <>
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm font-medium">Active</span>
                </>
              )}
              {distributionStatus === "completed" && (
                <>
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                  <span className="text-sm font-medium">Completed</span>
                </>
              )}
              {distributionStatus === "idle" && (
                <>
                  <AlertCircle className="w-4 h-4 text-gray-500" />
                  <span className="text-sm font-medium">Idle</span>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-slate-800">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="vectors">Distribution Vectors</TabsTrigger>
          <TabsTrigger value="networks">Networks</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle>Distribution Progress</CardTitle>
              <CardDescription>Real-time bloom seed deployment status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Overall Progress</span>
                    <span>{Math.round((seedsDeployed / 15000) * 100)}%</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${Math.round((seedsDeployed / 15000) * 100)}%` }}
                    ></div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mt-6">
                  <div className="bg-slate-700 p-4 rounded-lg">
                    <p className="text-sm text-gray-400">Estimated Reach</p>
                    <p className="text-2xl font-bold mt-2">8M+</p>
                    <p className="text-xs text-gray-500 mt-1">Potential targets</p>
                  </div>
                  <div className="bg-slate-700 p-4 rounded-lg">
                    <p className="text-sm text-gray-400">Deployment Time</p>
                    <p className="text-2xl font-bold mt-2">~2h 15m</p>
                    <p className="text-xs text-gray-500 mt-1">Estimated remaining</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Distribution Vectors Tab */}
        <TabsContent value="vectors" className="space-y-4">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle>Distribution Vectors</CardTitle>
              <CardDescription>Seeds deployed across different channels</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={distributionData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
                  <XAxis dataKey="vector" stroke="#94a3b8" angle={-45} textAnchor="end" height={100} />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #475569" }}
                    cursor={{ fill: "rgba(59, 130, 246, 0.1)" }}
                  />
                  <Legend />
                  <Bar dataKey="deployed" stackId="a" fill="#3b82f6" />
                  <Bar dataKey="pending" stackId="a" fill="#f59e0b" />
                </BarChart>
              </ResponsiveContainer>

              <div className="mt-6 space-y-3">
                {distributionData.map((item) => (
                  <div key={item.vector} className="flex items-center justify-between p-3 bg-slate-700 rounded-lg">
                    <span className="text-sm">{item.vector}</span>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-sm font-medium">{item.deployed} deployed</p>
                        <p className="text-xs text-gray-500">{item.pending} pending</p>
                      </div>
                      <div className="w-20 bg-slate-600 rounded-full h-2">
                        <div
                          className="bg-green-500 h-2 rounded-full"
                          style={{ width: `${(item.deployed / (item.deployed + item.pending)) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Networks Tab */}
        <TabsContent value="networks" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Surface Web */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Globe className="w-5 h-5 text-blue-500" />
                  <CardTitle>Surface Web</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm text-gray-400">Seeds Deployed</p>
                  <p className="text-2xl font-bold">4,200</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Active Targets</p>
                  <p className="text-2xl font-bold">1,245</p>
                </div>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">Manage Targets</Button>
              </CardContent>
            </Card>

            {/* Tor Network */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Network className="w-5 h-5 text-purple-500" />
                  <CardTitle>Tor Network</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm text-gray-400">Seeds Deployed</p>
                  <p className="text-2xl font-bold">3,800</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Hidden Services</p>
                  <p className="text-2xl font-bold">856</p>
                </div>
                <Button className="w-full bg-purple-600 hover:bg-purple-700">Manage Services</Button>
              </CardContent>
            </Card>

            {/* I2P Network */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-green-500" />
                  <CardTitle>I2P Network</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm text-gray-400">Seeds Deployed</p>
                  <p className="text-2xl font-bold">2,100</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Eepsites</p>
                  <p className="text-2xl font-bold">342</p>
                </div>
                <Button className="w-full bg-green-600 hover:bg-green-700">Manage Eepsites</Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-4">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle>Distribution Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie data={vectorDistribution} cx="50%" cy="50%" labelLine={false} label={({ name, value }) => `${name}: ${value}`} outerRadius={100} fill="#8884d8" dataKey="value">
                    {vectorDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #475569" }} />
                </PieChart>
              </ResponsiveContainer>

              <div className="mt-6 grid grid-cols-2 gap-4">
                <div className="bg-slate-700 p-4 rounded-lg">
                  <p className="text-sm text-gray-400">Average Deployment Time</p>
                  <p className="text-2xl font-bold mt-2">2.3 hours</p>
                </div>
                <div className="bg-slate-700 p-4 rounded-lg">
                  <p className="text-sm text-gray-400">Total Reach</p>
                  <p className="text-2xl font-bold mt-2">8.2M</p>
                </div>
                <div className="bg-slate-700 p-4 rounded-lg">
                  <p className="text-sm text-gray-400">Success Rate</p>
                  <p className="text-2xl font-bold mt-2">94.2%</p>
                </div>
                <div className="bg-slate-700 p-4 rounded-lg">
                  <p className="text-sm text-gray-400">Failed Deployments</p>
                  <p className="text-2xl font-bold mt-2">458</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
