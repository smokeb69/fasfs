import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import MainNavigation from "./components/MainNavigation";
import { useAuth } from "./_core/hooks/useAuth";
import { getLoginUrl } from "./const";
import { Loader2 } from "lucide-react";

// Import all pages
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import TeamOperations from "./pages/TeamOperations";
import ImageAnalysis from "./pages/ImageAnalysis";
import BloomSeedGenerator from "./pages/BloomSeedGenerator";
import AdminPanel from "./pages/AdminPanel";
import AlertCenter from "./pages/AlertCenter";
import InvestigationCases from "./pages/InvestigationCases";
import LESettings from "./pages/LESettings";
import IntelligentAlerts from "./pages/IntelligentAlerts";
import InvestigationTools from "./pages/InvestigationTools";
import CrawlerControl from "./pages/CrawlerControl";
import BloomDistribution from "./pages/BloomDistribution";
import EntityExtraction from "./pages/EntityExtraction";
import AIAlertSystem from "./pages/AIAlertSystem";
import RelationshipGraph from "./pages/RelationshipGraph";
import AuthDebug from "./pages/AuthDebug";

/**
 * Login Page
 */
function LoginPage() {

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-8 shadow-2xl">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">AGAPST RIIS</h1>
            <p className="text-gray-400">AI-Generated Abuse Prevention & Signature Tracker</p>
            <p className="text-gray-500 text-sm mt-2">Recursive Image Intervention System</p>
          </div>

          <div className="space-y-4">
            <p className="text-gray-400 text-center text-sm">
              Law enforcement platform for detecting and tracking AI-generated abuse content
            </p>

            <a href={getLoginUrl()} className="block">
              <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-lg transition flex items-center justify-center gap-2">
                <span>Sign in with Manus</span>
              </button>
            </a>

            <div className="mt-6 pt-6 border-t border-slate-700">
              <p className="text-xs text-gray-500 text-center">
                This system is restricted to authorized law enforcement personnel only.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/**
 * Loading Page
 */
function LoadingPage() {
  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center">
      <div className="text-center">
        <Loader2 className="w-12 h-12 text-blue-500 animate-spin mx-auto mb-4" />
        <p className="text-gray-400">Loading system...</p>
      </div>
    </div>
  );
}

/**
 * Main App Layout
 */
function AppLayout() {
  const [location] = useLocation();
  const { logout } = useAuth();
  const isLoginPage = location === "/login";

  return (
    <div className="flex h-screen bg-slate-900">
      {!isLoginPage && <MainNavigation logout={logout} />}
      <main className={`flex-1 overflow-auto ${isLoginPage ? "" : "md:ml-64"}`}>
        <Router />
      </main>
    </div>
  );
}

/**
 * Router
 */
function Router() {
  return (
    <Switch>
      {/* Public Routes */}
      <Route path={"/login"} component={LoginPage} />

      {/* Protected Routes */}
      <Route path={"/"} component={Home} />
      <Route path={"/dashboard"} component={Dashboard} />
      <Route path={"/team-operations"} component={TeamOperations} />
      <Route path={"/image-analysis"} component={ImageAnalysis} />
      <Route path={"/bloom-seed-generator"} component={BloomSeedGenerator} />
      <Route path={"/admin"} component={AdminPanel} />
      <Route path={"/alerts"} component={AlertCenter} />
      <Route path={"/cases"} component={InvestigationCases} />
      <Route path={"/le-settings"} component={LESettings} />
      <Route path={"/intelligent-alerts"} component={IntelligentAlerts} />
      <Route path={"/investigation-tools"} component={InvestigationTools} />
      <Route path={"/crawler-control"} component={CrawlerControl} />
      <Route path={"/bloom-distribution"} component={BloomDistribution} />
      <Route path={"/entity-extraction"} component={EntityExtraction} />
      <Route path={"/ai-alerts"} component={AIAlertSystem} />
            <Route path={"/relationship-graph"} component={RelationshipGraph} />
      <Route path={"/auth-debug"} component={AuthDebug} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

/**
 * Main App Component with Auth Check
 */
function App() {
  // TEST MODE: Bypass authentication
  const TEST_MODE = true;
  const { user, loading, isAuthenticated } = useAuth();

  // In test mode, skip authentication check
  if (TEST_MODE) {
    return (
      <ErrorBoundary>
        <ThemeProvider defaultTheme="dark">
          <TooltipProvider>
            <Toaster />
            <AppLayout />
          </TooltipProvider>
        </ThemeProvider>
      </ErrorBoundary>
    );
  }

  if (loading) {
    return <LoadingPage />;
  }

  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          {!isAuthenticated ? <LoginPage /> : <AppLayout />}
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
