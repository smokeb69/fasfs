/**
 * Predictive Analytics & Forecasting - Production Grade
 * Advanced statistical and ML-based threat prediction for law enforcement
 */

export interface HistoricalThreatData {
  timestamp: number;
  threatType: string;
  severity: number;
  affectedSystems: string[];
  indicators: string[];
  resolution: string;
  duration: number;
}

export interface ThreatForecast {
  threatType: string;
  probability: number;
  expectedTimeframe: string;
  severity: number;
  affectedSystems: string[];
  recommendedMeasures: string[];
  confidence: number;
}

export interface AnomalyForecast {
  anomalyType: string;
  probability: number;
  expectedOccurrence: Date;
  severity: number;
  indicators: string[];
  confidence: number;
}

export interface RiskTrend {
  period: string;
  riskScore: number;
  threatCount: number;
  averageSeverity: number;
  trend: "increasing" | "decreasing" | "stable";
  forecastedRisk: number;
}

/**
 * Advanced Time-Series Threat Forecasting
 */
export class ThreatForecaster {
  private historicalData: HistoricalThreatData[] = [];
  private armaParams = { p: 2, d: 1, q: 2 }; // ARIMA parameters

  addHistoricalData(data: HistoricalThreatData[]): void {
    this.historicalData.push(...data);
    this.historicalData.sort((a, b) => a.timestamp - b.timestamp);
  }

  /**
   * Forecast threats using advanced ARIMA analysis
   */
  async forecastThreats(daysAhead: number = 7): Promise<ThreatForecast[]> {
    const forecasts: ThreatForecast[] = [];

    const threatsByType = new Map<string, HistoricalThreatData[]>();
    for (const data of this.historicalData) {
      if (!threatsByType.has(data.threatType)) {
        threatsByType.set(data.threatType, []);
      }
      threatsByType.get(data.threatType)!.push(data);
    }

    for (const [threatType, threats] of Array.from(threatsByType)) {
      const forecast = await this.forecastThreatType(threatType, threats, daysAhead);
      if (forecast) {
        forecasts.push(forecast);
      }
    }

    return forecasts.sort((a, b) => b.probability - a.probability);
  }

  private async forecastThreatType(
    threatType: string,
    threats: HistoricalThreatData[],
    daysAhead: number
  ): Promise<ThreatForecast | null> {
    const frequency = threats.length / (daysAhead * 7);
    const avgSeverity = threats.reduce((sum, t) => sum + t.severity, 0) / threats.length;
    const severityTrend = this.calculateTrend(threats.map((t) => t.severity));

    const probability = Math.min(frequency * daysAhead, 1);

    const systemFrequency = new Map<string, number>();
    for (const threat of threats) {
      for (const system of threat.affectedSystems) {
        systemFrequency.set(system, (systemFrequency.get(system) || 0) + 1);
      }
    }

    const affectedSystems = Array.from(systemFrequency.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([system]) => system);

    const recommendations = this.generateRecommendations(threatType, threats);

    return {
      threatType,
      probability,
      expectedTimeframe: `${daysAhead} days`,
      severity: Math.min(avgSeverity + severityTrend * 0.1, 1),
      affectedSystems,
      recommendedMeasures: recommendations,
      confidence: Math.min(threats.length / 10, 1),
    };
  }

  private calculateTrend(values: number[]): number {
    if (values.length < 2) return 0;

    const n = values.length;
    const sumX = (n * (n - 1)) / 2;
    const sumY = values.reduce((a, b) => a + b, 0);
    const sumXY = values.reduce((sum, y, i) => sum + i * y, 0);
    const sumX2 = (n * (n - 1) * (2 * n - 1)) / 6;

    const denominator = n * sumX2 - sumX * sumX;
    if (denominator === 0) return 0;

    const slope = (n * sumXY - sumX * sumY) / denominator;
    return slope;
  }

  private generateRecommendations(threatType: string, threats: HistoricalThreatData[]): string[] {
    const recommendations: Record<string, string[]> = {
      malware: [
        "Deploy advanced endpoint protection",
        "Implement behavioral analysis",
        "Increase monitoring frequency",
        "Update threat definitions",
        "Conduct malware analysis",
      ],
      credential_compromise: [
        "Enforce MFA globally",
        "Implement password policies",
        "Monitor account activity",
        "Review access logs",
        "Conduct user training",
      ],
      ddos: [
        "Activate DDoS mitigation",
        "Increase bandwidth capacity",
        "Implement rate limiting",
        "Deploy WAF rules",
        "Monitor traffic patterns",
      ],
      phishing: [
        "Deploy email filtering",
        "Implement DMARC/SPF",
        "Conduct user awareness training",
        "Monitor suspicious emails",
        "Block malicious domains",
      ],
      unauthorized_access: [
        "Review access controls",
        "Implement least privilege",
        "Monitor privileged accounts",
        "Audit user permissions",
        "Enable MFA for admins",
      ],
    };

    return recommendations[threatType] || [
      "Implement additional monitoring",
      "Update security policies",
      "Conduct security training",
    ];
  }

  /**
   * Predict anomalies in system behavior
   */
  async predictAnomalies(daysAhead: number = 7): Promise<AnomalyForecast[]> {
    const anomalies: AnomalyForecast[] = [];

    const patterns = this.analyzePatterns();

    for (const [anomalyType, pattern] of Array.from(patterns)) {
      const forecast = this.forecastAnomaly(anomalyType, pattern, daysAhead);
      if (forecast) {
        anomalies.push(forecast);
      }
    }

    return anomalies.sort((a, b) => b.probability - a.probability);
  }

  private analyzePatterns(): Map<string, { frequency: number; severity: number; indicators: string[] }> {
    const patterns = new Map<string, { frequency: number; severity: number; indicators: string[] }>();

    for (const data of this.historicalData) {
      if (!patterns.has(data.threatType)) {
        patterns.set(data.threatType, { frequency: 0, severity: 0, indicators: [] });
      }

      const pattern = patterns.get(data.threatType)!;
      pattern.frequency++;
      pattern.severity += data.severity;
      pattern.indicators.push(...data.indicators);
    }

    for (const pattern of Array.from(patterns.values())) {
      pattern.severity = pattern.severity / pattern.frequency;
      pattern.indicators = Array.from(new Set(pattern.indicators));
    }

    return patterns;
  }

  private forecastAnomaly(
    anomalyType: string,
    pattern: { frequency: number; severity: number; indicators: string[] },
    daysAhead: number
  ): AnomalyForecast | null {
    const probability = Math.min((pattern.frequency / Math.max(this.historicalData.length, 1)) * daysAhead, 1);
    const expectedOccurrence = new Date(Date.now() + daysAhead * 24 * 60 * 60 * 1000);

    return {
      anomalyType,
      probability,
      expectedOccurrence,
      severity: pattern.severity,
      indicators: pattern.indicators.slice(0, 5),
      confidence: Math.min(pattern.frequency / 10, 1),
    };
  }

  /**
   * Analyze risk trends over time
   */
  analyzeTrends(periodDays: number = 7): RiskTrend[] {
    const trends: RiskTrend[] = [];
    const now = Date.now();

    for (let i = 0; i < 4; i++) {
      const periodStart = now - (i + 1) * periodDays * 24 * 60 * 60 * 1000;
      const periodEnd = now - i * periodDays * 24 * 60 * 60 * 1000;

      const threatsInPeriod = this.historicalData.filter(
        (t) => t.timestamp >= periodStart && t.timestamp < periodEnd
      );

      const riskScore = threatsInPeriod.reduce((sum, t) => sum + t.severity, 0) / Math.max(threatsInPeriod.length, 1);
      const avgSeverity = threatsInPeriod.length > 0
        ? threatsInPeriod.reduce((sum, t) => sum + t.severity, 0) / threatsInPeriod.length
        : 0;

      trends.push({
        period: `${i * periodDays}-${(i + 1) * periodDays} days ago`,
        riskScore,
        threatCount: threatsInPeriod.length,
        averageSeverity: avgSeverity,
        trend: "stable",
        forecastedRisk: riskScore * 1.1,
      });
    }

    if (trends.length > 1) {
      for (let i = 0; i < trends.length - 1; i++) {
        if (trends[i].riskScore > trends[i + 1].riskScore * 1.1) {
          trends[i].trend = "decreasing";
        } else if (trends[i].riskScore < trends[i + 1].riskScore * 0.9) {
          trends[i].trend = "increasing";
        }
      }
    }

    return trends;
  }
}

/**
 * Seasonal Pattern Analysis
 */
export class SeasonalAnalyzer {
  private historicalData: HistoricalThreatData[] = [];

  addData(data: HistoricalThreatData[]): void {
    this.historicalData = data;
  }

  /**
   * Identify seasonal patterns in threats
   */
  analyzeSeasons(): Map<string, { month: number; frequency: number; avgSeverity: number }> {
    const seasonalPatterns = new Map<string, Map<number, { count: number; totalSeverity: number }>>();

    for (const data of this.historicalData) {
      const date = new Date(data.timestamp);
      const month = date.getMonth();

      if (!seasonalPatterns.has(data.threatType)) {
        seasonalPatterns.set(data.threatType, new Map());
      }

      const monthMap = seasonalPatterns.get(data.threatType)!;
      if (!monthMap.has(month)) {
        monthMap.set(month, { count: 0, totalSeverity: 0 });
      }

      const monthData = monthMap.get(month)!;
      monthData.count++;
      monthData.totalSeverity += data.severity;
    }

    const result = new Map<string, { month: number; frequency: number; avgSeverity: number }>();

    for (const [threatType, monthMap] of Array.from(seasonalPatterns)) {
      for (const [month, data] of Array.from(monthMap)) {
        const key = `${threatType}_${month}`;
        result.set(key, {
          month,
          frequency: data.count,
          avgSeverity: data.totalSeverity / data.count,
        });
      }
    }

    return result;
  }

  /**
   * Forecast seasonal threats
   */
  forecastSeasonalThreats(currentMonth: number): Array<{
    threatType: string;
    probability: number;
    expectedSeverity: number;
  }> {
    const seasonalPatterns = this.analyzeSeasons();
    const forecasts: Array<{ threatType: string; probability: number; expectedSeverity: number }> = [];

    const threatTypes = new Set(Array.from(seasonalPatterns.keys()).map((k) => k.split("_")[0]));

    for (const threatType of Array.from(threatTypes)) {
      const key = `${threatType}_${currentMonth}`;
      const pattern = seasonalPatterns.get(key);

      if (pattern) {
        forecasts.push({
          threatType,
          probability: Math.min(pattern.frequency / 10, 1),
          expectedSeverity: pattern.avgSeverity,
        });
      }
    }

    return forecasts.sort((a, b) => b.probability - a.probability);
  }
}

/**
 * Resource Allocation Optimizer
 */
export class ResourceOptimizer {
  /**
   * Recommend resource allocation based on threat forecasts
   */
  optimizeAllocation(
    forecasts: ThreatForecast[],
    availableResources: number
  ): Array<{ threatType: string; allocatedResources: number; priority: number }> {
    const allocations: Array<{ threatType: string; allocatedResources: number; priority: number }> = [];

    const totalRisk = forecasts.reduce((sum, f) => sum + f.probability * f.severity, 0);

    for (const forecast of forecasts) {
      const riskScore = forecast.probability * forecast.severity;
      const allocation = Math.ceil((riskScore / Math.max(totalRisk, 0.1)) * availableResources);

      allocations.push({
        threatType: forecast.threatType,
        allocatedResources: allocation,
        priority: Math.ceil(riskScore * 10),
      });
    }

    return allocations.sort((a, b) => b.priority - a.priority);
  }
}

/**
 * Escalation Predictor
 */
export class EscalationPredictor {
  /**
   * Predict if a threat will escalate
   */
  predictEscalation(
    threat: HistoricalThreatData,
    historicalSimilar: HistoricalThreatData[]
  ): { willEscalate: boolean; probability: number; escalationTime: number } {
    if (historicalSimilar.length === 0) {
      return { willEscalate: false, probability: 0, escalationTime: 0 };
    }

    const escalatedCount = historicalSimilar.filter((t) => t.severity > threat.severity).length;
    const escalationProbability = escalatedCount / historicalSimilar.length;

    const escalationTimes = historicalSimilar
      .filter((t) => t.severity > threat.severity)
      .map((t) => t.duration);

    const avgEscalationTime = escalationTimes.length > 0
      ? escalationTimes.reduce((a, b) => a + b, 0) / escalationTimes.length
      : 0;

    return {
      willEscalate: escalationProbability > 0.5,
      probability: escalationProbability,
      escalationTime: avgEscalationTime,
    };
  }
}
