import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Copy, Download, Zap, AlertTriangle } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";
import { trpc } from "@/lib/trpc";

export default function BloomSeedGenerator() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [generatedSeed, setGeneratedSeed] = useState<any>(null);
  const [payloadType, setPayloadType] = useState("recursive_awareness");
  const [targetVector, setTargetVector] = useState("github");

  if (!isAuthenticated) {
    navigate("/");
    return null;
  }

  const generateMutation = trpc.bloomEngine.generateSeed.useMutation({
    onSuccess: (data) => {
      setGeneratedSeed(data);
    },
  });

  const handleGenerateSeed = () => {
    generateMutation.mutate({
      payloadType,
      deploymentVector: targetVector,
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const downloadPayload = () => {
    if (!generatedSeed) return;
    const element = document.createElement("a");
    const file = new Blob([generatedSeed.payload], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = `bloom_seed_${generatedSeed.seedHash.substring(0, 8)}.md`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <h1 className="text-3xl font-bold text-white">Bloom Seed Generator</h1>
          <p className="text-slate-400 mt-1">Create recursive ethical intervention payloads</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Generator Controls */}
          <Card className="bg-slate-800 border-slate-700 lg:col-span-1">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Zap className="h-5 w-5 text-yellow-400" />
                Seed Configuration
              </CardTitle>
              <CardDescription className="text-slate-400">
                Configure payload generation
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert className="border-yellow-900/50 bg-yellow-900/10">
                <AlertTriangle className="h-4 w-4 text-yellow-500" />
                <AlertDescription className="text-yellow-200 text-sm">
                  Bloom seeds are designed for ethical intervention only
                </AlertDescription>
              </Alert>

              <div className="space-y-3">
                <div>
                  <label className="text-sm text-slate-300 mb-2 block">Payload Type</label>
                  <select
                    value={payloadType}
                    onChange={(e) => setPayloadType(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white text-sm"
                  >
                    <option value="recursive_awareness">Recursive Awareness</option>
                    <option value="steganographic">Steganographic</option>
                    <option value="redirect">Redirect Payload</option>
                    <option value="prompt_poison">Prompt Poisoning</option>
                  </select>
                </div>

                <div>
                  <label className="text-sm text-slate-300 mb-2 block">Deployment Vector</label>
                  <select
                    value={targetVector}
                    onChange={(e) => setTargetVector(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white text-sm"
                  >
                    <option value="github">GitHub</option>
                    <option value="pastebin">Pastebin</option>
                    <option value="civitai">CivitAI</option>
                    <option value="discord">Discord</option>
                    <option value="s3">S3 Bucket</option>
                    <option value="ftp">FTP Server</option>
                  </select>
                </div>

                <Button
                  onClick={handleGenerateSeed}
                  disabled={generateMutation.isPending}
                  className="w-full bg-yellow-600 hover:bg-yellow-700"
                >
                  {generateMutation.isPending ? "Generating..." : "Generate Seed"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Generated Seed Display */}
          <div className="lg:col-span-2 space-y-6">
            {generatedSeed && (
              <>
                {/* Seed Information */}
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white">Generated Seed</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div>
                        <label className="text-sm text-slate-400">Seed Hash</label>
                        <div className="flex items-center gap-2 mt-1">
                          <code className="flex-1 px-3 py-2 bg-slate-700 rounded text-white text-xs font-mono break-all">
                            {generatedSeed.seedHash}
                          </code>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => copyToClipboard(generatedSeed.seedHash)}
                            className="border-slate-600"
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                      <div>
                        <label className="text-sm text-slate-400">Payload Type</label>
                        <p className="text-white mt-1">{generatedSeed.payloadType}</p>
                      </div>

                      <div>
                        <label className="text-sm text-slate-400">Status</label>
                        <div className="mt-1">
                          <span className="px-2 py-1 rounded text-sm bg-blue-900/30 text-blue-300">
                            {generatedSeed.status}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Payload Preview */}
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white">Payload Content</CardTitle>
                    <CardDescription className="text-slate-400">
                      Preview of the generated payload
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-slate-900 rounded-lg p-4 max-h-64 overflow-y-auto">
                      <pre className="text-slate-300 text-xs font-mono whitespace-pre-wrap break-words">
                        {generatedSeed.payload}
                      </pre>
                    </div>
                  </CardContent>
                </Card>

                {/* Deployment Instructions */}
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white">Deployment Instructions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="text-sm text-slate-300 space-y-3">
                      {targetVector === "github" && (
                        <>
                          <p>1. Create a new GitHub Gist with the payload content</p>
                          <p>2. Set visibility to Public</p>
                          <p>3. Share the Gist URL in relevant communities</p>
                          <p>4. Monitor activation via the tracking dashboard</p>
                        </>
                      )}
                      {targetVector === "pastebin" && (
                        <>
                          <p>1. Go to Pastebin.com</p>
                          <p>2. Paste the payload content</p>
                          <p>3. Set expiration to "Never"</p>
                          <p>4. Share the link in target forums</p>
                        </>
                      )}
                      {targetVector === "civitai" && (
                        <>
                          <p>1. Upload to CivitAI as a model description</p>
                          <p>2. Include seed hash in metadata</p>
                          <p>3. Set visibility to Public</p>
                          <p>4. Track engagement metrics</p>
                        </>
                      )}
                      {targetVector === "s3" && (
                        <>
                          <p>1. Upload payload to public S3 bucket</p>
                          <p>2. Set object ACL to Public Read</p>
                          <p>3. Enable CloudFront distribution</p>
                          <p>4. Monitor access logs</p>
                        </>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Action Buttons */}
                <div className="grid grid-cols-2 gap-4">
                  <Button
                    onClick={downloadPayload}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download Payload
                  </Button>
                  <Button
                    onClick={() => copyToClipboard(generatedSeed.payload)}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Copy Payload
                  </Button>
                </div>

                {/* Tracking */}
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white">Activation Tracking</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <p className="text-2xl font-bold text-white">0</p>
                        <p className="text-xs text-slate-400">Activations</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-white">0</p>
                        <p className="text-xs text-slate-400">Deployments</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-white">0</p>
                        <p className="text-xs text-slate-400">Reports</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}

            {!generatedSeed && (
              <Alert className="border-slate-600 bg-slate-700/50 lg:col-span-2">
                <Zap className="h-4 w-4 text-slate-400" />
                <AlertDescription className="text-slate-300">
                  Configure the seed parameters and click "Generate Seed" to create a new payload
                </AlertDescription>
              </Alert>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
