export const COOKIE_NAME = "app_session_id";
export const ONE_YEAR_MS = 1000 * 60 * 60 * 24 * 365;
export const AXIOS_TIMEOUT_MS = 30_000;
export const UNAUTHED_ERR_MSG = 'Please login (10001)';
export const NOT_ADMIN_ERR_MSG = 'You do not have required permission (10002)';

// App branding and configuration
export const APP_TITLE = process.env.VITE_APP_TITLE || "AGAPST RIIS";
export const APP_LOGO = process.env.VITE_APP_LOGO || "/logo.svg";
export const APP_ID = process.env.VITE_APP_ID || "bloom_distribution";

// OAuth configuration
export const OAUTH_PORTAL_URL = process.env.VITE_OAUTH_PORTAL_URL || "https://oauth.manus.im";

/**
 * Get the login URL for OAuth redirect
 */
export function getLoginUrl(): string {
  const redirectUri = typeof window !== "undefined" ? window.location.origin : "http://localhost:3000";
  const params = new URLSearchParams({
    client_id: APP_ID,
    redirect_uri: `${redirectUri}/api/oauth/callback`,
    response_type: "code",
    scope: "openid profile email",
  });
  return `${OAUTH_PORTAL_URL}/authorize?${params.toString()}`;
}
