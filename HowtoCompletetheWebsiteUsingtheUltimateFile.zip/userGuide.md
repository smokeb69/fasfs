# Bloom Distribution System User Guide

## Website Overview

**Purpose:** Deploy and manage bloom seed distribution across multiple networks and channels with real-time monitoring and advanced analytics.

**Access:** Public access available; authentication required for distribution control operations.

---

## Powered by Manus

This website is built with cutting-edge technology:

**Frontend:** React 19 with TypeScript, Tailwind CSS 4, and Recharts for data visualization.

**Backend:** Express 4 with tRPC 11 for type-safe API communication, integrated with Manus OAuth authentication.

**Database:** MySQL/TiDB with Drizzle ORM for robust data persistence and audit logging.

**Authentication:** Manus OAuth integration with secure session management.

**Deployment:** Auto-scaling infrastructure with global CDN for optimal performance and reliability.

---

## Using Your Website

### 1. Accessing the Dashboard

Navigate to the "Open Distribution Dashboard" button on the home page to access the main control panel. The dashboard displays real-time metrics including seeds deployed, distribution vectors, and success rates across all active channels.

### 2. Starting a Distribution

Click the "Start Distribution" button in the dashboard header to initiate bloom seed deployment. The system will begin distributing seeds across eight active channels including GitHub Gist, Pastebin, CivitAI Comments, Reddit Posts, Discord Messages, Image Metadata, Steganography, and DNS Records. Monitor the progress bar to track overall deployment status.

### 3. Monitoring Distribution Progress

The "Overview" tab shows your distribution progress with a real-time progress bar. View estimated reach (8M+ potential targets) and deployment time estimates. The status indicator shows whether distribution is idle, active, or completed.

### 4. Analyzing Distribution Vectors

Switch to the "Distribution Vectors" tab to see detailed deployment metrics for each channel. Each vector displays deployed count, pending items, and a progress indicator. A stacked bar chart provides visual comparison across all eight distribution channels.

### 5. Managing Networks

The "Networks" tab allows you to manage deployment across three network types: Surface Web (4,200 seeds deployed), Tor Network (3,100 seeds deployed), and I2P Network (2,800 seeds deployed). Each network card shows active targets and provides individual management controls.

### 6. Reviewing Analytics

The "Analytics" tab displays comprehensive insights including a pie chart showing vector distribution breakdown and a line chart tracking seeds deployed over time. Use these visualizations to understand deployment patterns and optimize future operations.

---

## Managing Your Website

### Dashboard Panel

Access the Dashboard from the Management UI to view real-time metrics, visibility settings, and analytics (UV/PV) for your site.

### Settings Panel

Configure your website through Settings → General to manage website name and logo. Use Settings → Domains to modify your auto-generated domain or bind custom domains. Settings → Secrets allows you to manage environment variables securely.

### Database Panel

Access the Database panel in the Management UI to view your data structure, perform CRUD operations, and manage distribution logs. Full connection information is available in the Settings panel (remember to enable SSL for production).

### Notifications

Configure notification settings through Settings → Notifications to receive alerts about distribution events and system status updates.

---

## Next Steps

Talk to Manus AI anytime to request changes or add features. You can expand the distribution system with additional vectors, implement custom filtering rules, or integrate with external monitoring services.

Ready to scale your distribution? Click "Go to Dashboard" to start managing your bloom seed deployment operations today.
