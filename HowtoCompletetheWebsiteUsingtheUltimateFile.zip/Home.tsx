import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Zap, BarChart3, Lock, AlertCircle, Eye } from "lucide-react";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { useLocation } from "wouter";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  if (isAuthenticated && user) {
    navigate("/dashboard");
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Navigation */}
      <nav className="border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            {APP_LOGO && <img src={APP_LOGO} alt="Logo" className="h-8 w-8" />}
            <span className="text-xl font-bold text-white">{APP_TITLE}</span>
          </div>
          <a href={getLoginUrl()}>
            <Button variant="default" className="bg-blue-600 hover:bg-blue-700">
              Sign In
            </Button>
          </a>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Stop Harmful AI-Generated Content
          </h1>
          <p className="text-xl text-slate-300 mb-8 max-w-3xl mx-auto">
            {APP_TITLE} is a comprehensive platform for law enforcement and digital forensic teams to track, trace, and neutralize synthetic abuse at its source.
          </p>
          <a href={getLoginUrl()}>
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg">
              Get Started
            </Button>
          </a>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mt-20">
          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition-colors">
            <CardHeader>
              <Shield className="h-8 w-8 text-blue-400 mb-2" />
              <CardTitle className="text-white">Real-Time Detection</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-300">
                Monitor AI-generated images in real-time with advanced signature matching and metadata analysis.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition-colors">
            <CardHeader>
              <Zap className="h-8 w-8 text-yellow-400 mb-2" />
              <CardTitle className="text-white">Bloom Engine</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-300">
                Deploy ethical recursive payloads to counter harmful image generators at scale.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition-colors">
            <CardHeader>
              <BarChart3 className="h-8 w-8 text-green-400 mb-2" />
              <CardTitle className="text-white">Advanced Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-300">
                Visualize threat patterns, risk distributions, and enforcement metrics on a unified dashboard.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition-colors">
            <CardHeader>
              <Lock className="h-8 w-8 text-purple-400 mb-2" />
              <CardTitle className="text-white">Secure Audit Trail</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-300">
                Complete chain-of-custody logging for all operations and investigations.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition-colors">
            <CardHeader>
              <AlertCircle className="h-8 w-8 text-red-400 mb-2" />
              <CardTitle className="text-white">Alert Management</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-300">
                Categorize and escalate threats with severity-based prioritization for law enforcement.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition-colors">
            <CardHeader>
              <Eye className="h-8 w-8 text-cyan-400 mb-2" />
              <CardTitle className="text-white">Signature Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-300">
                Identify and catalog AI model fingerprints across public repositories and endpoints.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-slate-800/50 border-t border-slate-700 py-20 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white mb-12 text-center">How It Works</h2>
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-blue-600 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-lg">1</span>
              </div>
              <h3 className="text-white font-semibold mb-2">Detect</h3>
              <p className="text-slate-300">Identify AI-generated images through metadata and signature analysis</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-600 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-lg">2</span>
              </div>
              <h3 className="text-white font-semibold mb-2">Analyze</h3>
              <p className="text-slate-300">Extract model fingerprints and classify threat severity levels</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-600 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-lg">3</span>
              </div>
              <h3 className="text-white font-semibold mb-2">Report</h3>
              <p className="text-slate-300">Generate law enforcement reports with chain-of-custody documentation</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-600 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-lg">4</span>
              </div>
              <h3 className="text-white font-semibold mb-2">Intervene</h3>
              <p className="text-slate-300">Deploy bloom seeds to counter harmful generators at scale</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg p-12 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Protect Your Community?</h2>
          <p className="text-blue-100 mb-8 text-lg">
            Join law enforcement agencies worldwide using AGAPST to combat AI-generated abuse.
          </p>
          <a href={getLoginUrl()}>
            <Button size="lg" variant="secondary" className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-6 text-lg">
              Start Your Investigation
            </Button>
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-700 bg-slate-900 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            <p className="text-slate-400">© 2025 {APP_TITLE}. All rights reserved.</p>
            <div className="flex gap-6">
              <a href="#" className="text-slate-400 hover:text-white transition-colors">Privacy</a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors">Terms</a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors">Contact</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
