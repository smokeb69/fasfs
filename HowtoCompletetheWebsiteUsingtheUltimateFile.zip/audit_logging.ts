import crypto from "crypto";

/**
 * Comprehensive Audit Logging & Compliance - Production Grade
 * Government-grade audit trail, compliance tracking, and forensic logging
 */

export interface AuditLog {
  id: string;
  timestamp: Date;
  userId: string;
  action: string;
  resource: string;
  resourceId: string;
  status: "success" | "failure" | "pending";
  details: Record<string, any>;
  ipAddress: string;
  userAgent: string;
  severity: "critical" | "high" | "medium" | "low" | "info";
  complianceFrameworks: string[];
  hash: string; // For integrity verification
  previousHash?: string; // For chain of custody
}

export interface ComplianceViolation {
  id: string;
  timestamp: Date;
  framework: string;
  requirement: string;
  severity: "critical" | "high" | "medium" | "low";
  description: string;
  affectedResource: string;
  remediation: string;
  status: "open" | "in_progress" | "resolved";
}

export interface ComplianceReport {
  timestamp: Date;
  framework: string;
  totalRequirements: number;
  compliantRequirements: number;
  compliancePercentage: number;
  violations: ComplianceViolation[];
  recommendations: string[];
}

/**
 * Audit Logger
 * Maintains immutable audit trail with cryptographic integrity
 */
export class AuditLogger {
  private logs: AuditLog[] = [];
  private logIndex: Map<string, AuditLog> = new Map();
  private lastHash: string = "";

  /**
   * Log an action
   */
  logAction(
    userId: string,
    action: string,
    resource: string,
    resourceId: string,
    details: Record<string, any>,
    ipAddress: string,
    userAgent: string,
    severity: "critical" | "high" | "medium" | "low" | "info" = "info"
  ): AuditLog {
    const logId = `audit_${crypto.randomBytes(8).toString("hex")}`;
    const timestamp = new Date();

    // Determine compliance frameworks affected
    const complianceFrameworks = this.determineComplianceFrameworks(action, resource);

    // Create audit log entry
    const logEntry: AuditLog = {
      id: logId,
      timestamp,
      userId,
      action,
      resource,
      resourceId,
      status: "success",
      details,
      ipAddress,
      userAgent,
      severity,
      complianceFrameworks,
      hash: "",
      previousHash: this.lastHash,
    };

    // Calculate hash for integrity
    logEntry.hash = this.calculateLogHash(logEntry);
    this.lastHash = logEntry.hash;

    // Store log
    this.logs.push(logEntry);
    this.logIndex.set(logId, logEntry);

    return logEntry;
  }

  /**
   * Determine applicable compliance frameworks
   */
  private determineComplianceFrameworks(action: string, resource: string): string[] {
    const frameworks: string[] = [];

    // HIPAA - if handling health data
    if (resource.includes("health") || resource.includes("medical")) {
      frameworks.push("HIPAA");
    }

    // GDPR - if handling personal data
    if (resource.includes("user") || resource.includes("personal") || resource.includes("data")) {
      frameworks.push("GDPR");
    }

    // FISMA - if federal information system
    if (resource.includes("federal") || resource.includes("government")) {
      frameworks.push("FISMA");
    }

    // SOC 2 - general security controls
    frameworks.push("SOC2");

    // PCI-DSS - if handling payment data
    if (resource.includes("payment") || resource.includes("card") || resource.includes("financial")) {
      frameworks.push("PCI-DSS");
    }

    // NIST - cybersecurity framework
    frameworks.push("NIST");

    return frameworks;
  }

  /**
   * Calculate cryptographic hash for log entry
   */
  private calculateLogHash(log: AuditLog): string {
    const logString = JSON.stringify({
      timestamp: log.timestamp,
      userId: log.userId,
      action: log.action,
      resource: log.resource,
      resourceId: log.resourceId,
      details: log.details,
      previousHash: log.previousHash,
    });

    return crypto.createHash("sha256").update(logString).digest("hex");
  }

  /**
   * Verify log integrity
   */
  verifyLogIntegrity(logId: string): boolean {
    const log = this.logIndex.get(logId);
    if (!log) return false;

    const calculatedHash = this.calculateLogHash(log);
    return calculatedHash === log.hash;
  }

  /**
   * Verify entire audit trail integrity
   */
  verifyAuditTrailIntegrity(): boolean {
    for (let i = 0; i < this.logs.length; i++) {
      const log = this.logs[i];

      // Verify current log hash
      if (!this.verifyLogIntegrity(log.id)) {
        return false;
      }

      // Verify chain of custody
      if (i > 0 && log.previousHash !== this.logs[i - 1].hash) {
        return false;
      }
    }

    return true;
  }

  /**
   * Get logs for user
   */
  getLogsForUser(userId: string): AuditLog[] {
    return this.logs.filter((log) => log.userId === userId);
  }

  /**
   * Get logs for resource
   */
  getLogsForResource(resource: string, resourceId: string): AuditLog[] {
    return this.logs.filter((log) => log.resource === resource && log.resourceId === resourceId);
  }

  /**
   * Get logs by action
   */
  getLogsByAction(action: string): AuditLog[] {
    return this.logs.filter((log) => log.action === action);
  }

  /**
   * Get logs by severity
   */
  getLogsBySeverity(severity: string): AuditLog[] {
    return this.logs.filter((log) => log.severity === severity);
  }

  /**
   * Get logs within time range
   */
  getLogsInTimeRange(startTime: Date, endTime: Date): AuditLog[] {
    return this.logs.filter((log) => log.timestamp >= startTime && log.timestamp <= endTime);
  }

  /**
   * Export audit logs
   */
  exportLogs(format: "json" | "csv" = "json"): string {
    if (format === "json") {
      return JSON.stringify(this.logs, null, 2);
    } else if (format === "csv") {
      const headers = ["ID", "Timestamp", "User ID", "Action", "Resource", "Status", "Severity"];
      const rows = this.logs.map((log) => [
        log.id,
        log.timestamp.toISOString(),
        log.userId,
        log.action,
        log.resource,
        log.status,
        log.severity,
      ]);

      const csvContent = [
        headers.join(","),
        ...rows.map((row) => row.map((cell) => `"${cell}"`).join(",")),
      ].join("\n");

      return csvContent;
    }

    return "";
  }

  /**
   * Get audit statistics
   */
  getStatistics() {
    const totalLogs = this.logs.length;
    const successfulActions = this.logs.filter((log) => log.status === "success").length;
    const failedActions = this.logs.filter((log) => log.status === "failure").length;

    const severityCount = {
      critical: this.logs.filter((log) => log.severity === "critical").length,
      high: this.logs.filter((log) => log.severity === "high").length,
      medium: this.logs.filter((log) => log.severity === "medium").length,
      low: this.logs.filter((log) => log.severity === "low").length,
      info: this.logs.filter((log) => log.severity === "info").length,
    };

    return {
      totalLogs,
      successfulActions,
      failedActions,
      successRate: (successfulActions / Math.max(totalLogs, 1)) * 100,
      severityCount,
    };
  }
}

/**
 * Compliance Checker
 * Monitors and reports compliance violations
 */
export class ComplianceChecker {
  private violations: ComplianceViolation[] = [];
  private complianceRules: Map<string, ComplianceRule[]> = new Map();

  constructor() {
    this.initializeComplianceRules();
  }

  /**
   * Initialize compliance rules
   */
  private initializeComplianceRules(): void {
    // GDPR Rules
    const gdprRules: ComplianceRule[] = [
      {
        id: "gdpr_1",
        requirement: "Data minimization",
        check: (log) => !log.details.sensitiveData || log.details.sensitiveData.length === 0,
      },
      {
        id: "gdpr_2",
        requirement: "Purpose limitation",
        check: (log) => log.action === "data_access" && log.details.purpose !== undefined,
      },
      {
        id: "gdpr_3",
        requirement: "Storage limitation",
        check: (log) => log.details.retentionPeriod !== undefined,
      },
      {
        id: "gdpr_4",
        requirement: "Integrity and confidentiality",
        check: (log) => log.details.encrypted === true,
      },
    ];

    // HIPAA Rules
    const hipaaRules: ComplianceRule[] = [
      {
        id: "hipaa_1",
        requirement: "Access controls",
        check: (log) => log.userId !== undefined && log.ipAddress !== undefined,
      },
      {
        id: "hipaa_2",
        requirement: "Audit controls",
        check: (log) => log.timestamp !== undefined && log.action !== undefined,
      },
      {
        id: "hipaa_3",
        requirement: "Encryption",
        check: (log) => log.details.encrypted === true,
      },
    ];

    // SOC 2 Rules
    const soc2Rules: ComplianceRule[] = [
      {
        id: "soc2_1",
        requirement: "User access logging",
        check: (log) => log.userId !== undefined,
      },
      {
        id: "soc2_2",
        requirement: "System activity logging",
        check: (log) => log.timestamp !== undefined,
      },
      {
        id: "soc2_3",
        requirement: "Security event monitoring",
        check: (log) => log.severity !== undefined,
      },
    ];

    // FISMA Rules
    const fismaRules: ComplianceRule[] = [
      {
        id: "fisma_1",
        requirement: "Access control",
        check: (log) => log.userId !== undefined && log.ipAddress !== undefined,
      },
      {
        id: "fisma_2",
        requirement: "Identification and authentication",
        check: (log) => log.userId !== undefined,
      },
      {
        id: "fisma_3",
        requirement: "Audit and accountability",
        check: (log) => log.timestamp !== undefined && log.action !== undefined,
      },
    ];

    this.complianceRules.set("GDPR", gdprRules);
    this.complianceRules.set("HIPAA", hipaaRules);
    this.complianceRules.set("SOC2", soc2Rules);
    this.complianceRules.set("FISMA", fismaRules);
  }

  /**
   * Check compliance for log
   */
  checkCompliance(log: AuditLog): ComplianceViolation[] {
    const violations: ComplianceViolation[] = [];

    for (const framework of log.complianceFrameworks) {
      const rules = this.complianceRules.get(framework) || [];

      for (const rule of rules) {
        if (!rule.check(log)) {
          violations.push({
            id: `violation_${crypto.randomBytes(8).toString("hex")}`,
            timestamp: new Date(),
            framework,
            requirement: rule.requirement,
            severity: "high",
            description: `${framework} requirement "${rule.requirement}" not met for action: ${log.action}`,
            affectedResource: `${log.resource}/${log.resourceId}`,
            remediation: this.getRemediation(framework, rule.requirement),
            status: "open",
          });
        }
      }
    }

    this.violations.push(...violations);
    return violations;
  }

  /**
   * Get remediation steps
   */
  private getRemediation(framework: string, requirement: string): string {
    const remediations: Record<string, Record<string, string>> = {
      GDPR: {
        "Data minimization": "Review and minimize collected personal data",
        "Purpose limitation": "Ensure data is only used for stated purposes",
        "Storage limitation": "Implement data retention policies",
        "Integrity and confidentiality": "Enable encryption for all personal data",
      },
      HIPAA: {
        "Access controls": "Implement role-based access controls",
        "Audit controls": "Enable comprehensive audit logging",
        Encryption: "Encrypt all protected health information",
      },
      SOC2: {
        "User access logging": "Log all user access events",
        "System activity logging": "Log all system activities",
        "Security event monitoring": "Monitor and alert on security events",
      },
      FISMA: {
        "Access control": "Implement federal access control standards",
        "Identification and authentication": "Implement strong authentication",
        "Audit and accountability": "Maintain comprehensive audit trails",
      },
    };

    return (
      remediations[framework]?.[requirement] || "Review compliance requirements and implement controls"
    );
  }

  /**
   * Generate compliance report
   */
  generateComplianceReport(framework: string): ComplianceReport {
    const rules = this.complianceRules.get(framework) || [];
    const frameworkViolations = this.violations.filter((v) => v.framework === framework);

    const compliantRequirements = rules.length - frameworkViolations.length;
    const compliancePercentage = (compliantRequirements / Math.max(rules.length, 1)) * 100;

    return {
      timestamp: new Date(),
      framework,
      totalRequirements: rules.length,
      compliantRequirements,
      compliancePercentage,
      violations: frameworkViolations,
      recommendations: this.generateRecommendations(framework, frameworkViolations),
    };
  }

  /**
   * Generate recommendations
   */
  private generateRecommendations(framework: string, violations: ComplianceViolation[]): string[] {
    const recommendations: string[] = [];

    if (violations.length === 0) {
      recommendations.push(`${framework} compliance is fully met`);
    } else {
      recommendations.push(`Address ${violations.length} compliance violations`);
      recommendations.push("Implement missing controls");
      recommendations.push("Schedule compliance audit");
      recommendations.push("Update compliance documentation");
    }

    return recommendations;
  }

  /**
   * Get all violations
   */
  getAllViolations(): ComplianceViolation[] {
    return this.violations;
  }

  /**
   * Get violations by framework
   */
  getViolationsByFramework(framework: string): ComplianceViolation[] {
    return this.violations.filter((v) => v.framework === framework);
  }
}

interface ComplianceRule {
  id: string;
  requirement: string;
  check: (log: AuditLog) => boolean;
}

/**
 * Forensic Analyzer
 * Analyzes audit logs for forensic investigation
 */
export class ForensicAnalyzer {
  /**
   * Analyze suspicious activity
   */
  analyzeSuspiciousActivity(logs: AuditLog[]): {
    suspiciousPatterns: string[];
    riskScore: number;
    recommendations: string[];
  } {
    const patterns: string[] = [];
    let riskScore = 0;

    // Check for multiple failed attempts
    const failedAttempts = logs.filter((log) => log.status === "failure");
    if (failedAttempts.length > 5) {
      patterns.push("Multiple failed authentication attempts");
      riskScore += 0.2;
    }

    // Check for unusual access times
    const unusualTimes = logs.filter((log) => {
      const hour = log.timestamp.getHours();
      return hour < 6 || hour > 22;
    });
    if (unusualTimes.length > logs.length * 0.5) {
      patterns.push("Unusual access times detected");
      riskScore += 0.15;
    }

    // Check for data exfiltration patterns
    const dataAccess = logs.filter((log) => log.action === "data_access");
    if (dataAccess.length > 10 && dataAccess.length > logs.length * 0.7) {
      patterns.push("Potential data exfiltration pattern");
      riskScore += 0.3;
    }

    // Check for privilege escalation
    const privilegeChanges = logs.filter((log) => log.action === "privilege_change");
    if (privilegeChanges.length > 2) {
      patterns.push("Multiple privilege escalation attempts");
      riskScore += 0.25;
    }

    const recommendations = [
      "Conduct detailed forensic investigation",
      "Review user access patterns",
      "Check for compromised credentials",
      "Implement additional monitoring",
      "Preserve all evidence for investigation",
    ];

    return {
      suspiciousPatterns: patterns,
      riskScore: Math.min(riskScore, 1),
      recommendations,
    };
  }

  /**
   * Generate forensic report
   */
  generateForensicReport(logs: AuditLog[]): string {
    const analysis = this.analyzeSuspiciousActivity(logs);

    let report = "=== FORENSIC INVESTIGATION REPORT ===\n\n";
    report += `Generated: ${new Date().toISOString()}\n`;
    report += `Total Logs Analyzed: ${logs.length}\n\n`;

    report += "SUSPICIOUS PATTERNS DETECTED:\n";
    for (const pattern of analysis.suspiciousPatterns) {
      report += `- ${pattern}\n`;
    }

    report += `\nRisk Score: ${(analysis.riskScore * 100).toFixed(1)}%\n\n`;

    report += "RECOMMENDATIONS:\n";
    for (const recommendation of analysis.recommendations) {
      report += `- ${recommendation}\n`;
    }

    return report;
  }
}

/**
 * Log an audit event
 */
export async function logAuditEvent(
  userId: string,
  action: string,
  resource: string,
  resourceId: string,
  details: Record<string, any>,
  ipAddress: string,
  userAgent: string
): Promise<AuditLog> {
  const logger = new AuditLogger();
  return logger.logAction(userId, action, resource, resourceId, details, ipAddress, userAgent);
}

/**
 * Check compliance
 */
export async function checkCompliance(log: AuditLog): Promise<ComplianceViolation[]> {
  const checker = new ComplianceChecker();
  return checker.checkCompliance(log);
}
